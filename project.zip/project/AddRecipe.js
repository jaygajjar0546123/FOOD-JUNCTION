import React, { useState, useEffect } from 'react';
import { db } from './FirebaseConfig';
import { collection, addDoc, getDocs } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";
import './AddRecipe.css';
import { onSnapshot } from 'firebase/firestore';

function AddRecipe() {
  const [name, setName] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [steps, setSteps] = useState('');
  const [imageFile, setImageFile] = useState(null);
  const [message, setMessage] = useState('');
  const [recipes, setRecipes] = useState([]); // State to store recipes

  // Fetch recipes from Firebase Firestore and listen for real-time updates
  useEffect(() => {
    // Fetch data on page load
    const fetchRecipes = async () => {
      const snapshot = await getDocs(collection(db, 'recipes'));
      const recipeList = snapshot.docs.map(doc => doc.data());
      setRecipes(recipeList);
    };

    fetchRecipes(); // Fetch recipes initially when the page loads

    const unsubscribe = onSnapshot(collection(db, 'recipes'), (snapshot) => {
      const recipeList = snapshot.docs.map(doc => doc.data());
      setRecipes(recipeList);
    });

    // Cleanup on unmount
    return () => unsubscribe();
  }, []);

  const handleImageChange = (e) => {
    if (e.target.files[0]) {
      setImageFile(e.target.files[0]);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    try {
      let imageUrl = "";
      if (imageFile) {
        const storage = getStorage();
        const imageRef = ref(storage, `recipe-images/${imageFile.name}-${Date.now()}`);
        await uploadBytes(imageRef, imageFile);
        imageUrl = await getDownloadURL(imageRef);
      }

      // Add the recipe to Firestore
      await addDoc(collection(db, "recipes"), {
        name,
        ingredients,
        steps,
        imageUrl,
      });

      // Reset form
      setName('');
      setIngredients('');
      setSteps('');
      setImageFile(null);
      setMessage('Recipe added successfully!');
    } catch (err) {
      setMessage('Failed to add recipe. Please try again.');
    }
  };

  return (
    <div className="form-container">
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Recipe Name</label>
        <input id="name" placeholder="Recipe Name" value={name} onChange={(e) => setName(e.target.value)} />

        <label htmlFor="ingredients">Ingredients</label>
        <textarea id="ingredients" placeholder="Ingredients" value={ingredients} onChange={(e) => setIngredients(e.target.value)} />

        <label htmlFor="steps">Steps</label>
        <textarea id="steps" placeholder="Steps" value={steps} onChange={(e) => setSteps(e.target.value)} />

        <label htmlFor="image">Upload Image</label>
        <input id="image" type="file" accept="image/*" onChange={handleImageChange} />

        <button type="submit">Add Recipe</button>
      </form>

      {message && <p className="message">{message}</p>}

      <h2>Recipe List</h2>
      <ul>
        {recipes.length === 0 ? (
          <p>No recipes available.</p>
        ) : (
          recipes.map((recipe, index) => (
            <li key={index}>
              <h3>{recipe.name}</h3>
              <p>{recipe.ingredients}</p>
              <p>{recipe.steps}</p>
              {recipe.imageUrl && <img src={recipe.imageUrl} alt={recipe.name} width="100" />}
            </li>
          ))
        )}
      </ul>
    </div>
  );
}

export default AddRecipe;
