import React, { useState, useEffect } from "react";
import { collection, onSnapshot } from "firebase/firestore";
import { db } from './FirebaseConfig';

import './Home.css';

const Home = () => {
  const [recipes, setRecipes] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [openIndex, setOpenIndex] = useState(null);

  // Fetch recipes from Firestore
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "recipes"), (snapshot) => {
      const fetchedRecipes = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setRecipes(fetchedRecipes);
    });

    return () => unsubscribe();
  }, []);

  // Handle recipe accordion toggle
  const toggleRecipe = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  // Handle search input
  const handleSearchChange = (e) => {
    setSearchQuery(e.target.value.toLowerCase());
  };

  // Filter recipes by search query
  const filteredRecipes = recipes.filter(recipe =>
    recipe.name.toLowerCase().includes(searchQuery)
  );

  return (
    <div className="home-container">
      {/* Hero Section */}
      <header className="hero">
        <h1>🍕 Food Junction</h1>
        <p>Your one-stop place for delicious food recipes</p>
      </header>

      {/* Search Bar */}
      <div className="search-container">
        <input
          type="text"
          placeholder="Search for a recipe..."
          value={searchQuery}
          onChange={handleSearchChange}
          className="search-input"
        />
      </div>

      {/* Recipes Section */}
      <section>
        <h2 className="section-title">✨ Featured Recipes</h2>

        <div className="recipes">
          {filteredRecipes.length > 0 ? (
            filteredRecipes.map((recipe, index) => {
              const isOpen = openIndex === index;
              return (
                <div className={`card ${isOpen ? 'open' : ''}`} key={recipe.id}>
                  
                  {/* Show image if available */}
                  {recipe.imageUrl && (
                    <img
                      src={recipe.imageUrl}
                      alt={recipe.name}
                      className="recipe-image"
                    />
                  )}

                  <div onClick={() => toggleRecipe(index)} className="card-body">
                    <h3>{recipe.name}</h3>
                  </div>

                  {isOpen && (
                    <div className="recipe-details">
                      <h3>Ingredients:</h3>
                      <ul>
                        {recipe.ingredients?.split(',').map((ingredient, i) => (
                          <li key={i}>{ingredient.trim()}</li>
                        ))}
                      </ul>

                      <h3>Instructions:</h3>
                      <ol>
                        {recipe.steps?.split('.').filter(step => step.trim()).map((step, i) => (
                          <li key={i}>{step.trim()}</li>
                        ))}
                      </ol>
                    </div>
                  )}
                </div>
              );
            })
          ) : (
            <p>No recipes found. Try searching again!</p>
          )}
        </div>
      </section>
    </div>
  );
};

export default Home;
