// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyBssBVTpFccHW3NYMJc4vny04FrYht0rT8",
  authDomain: "food-junction-daff4.firebaseapp.com",
  projectId: "food-junction-daff4",
  storageBucket: "food-junction-daff4.firebasestorage.app",
  messagingSenderId: "234797046028",
  appId: "1:234797046028:web:4bf5e5dc2b616eb5245129",
  measurementId: "G-NDoJSXZKFT6"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);
const auth = getAuth(app);

export { db, auth };
