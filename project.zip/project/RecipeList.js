import React, { useEffect, useState } from 'react';
import { db } from './FirebaseConfig';
import { collection, onSnapshot, deleteDoc, doc } from 'firebase/firestore';

function RecipeList() {
  const [recipes, setRecipes] = useState([]);

  useEffect(() => {
    const unsub = onSnapshot(collection(db, "recipes"), (snapshot) => {
      setRecipes(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });

    return () => unsub();
  }, []);

  const handleDelete = async (id) => {
    if (window.confirm("Are you sure you want to delete this recipe?")) {
      try {
        await deleteDoc(doc(db, "recipes", id));
      } catch (error) {
        console.error("Error deleting recipe: ", error);
      }
    }
  };

  return (
    <div>
      <h2>All Recipes</h2>
      {recipes.map((recipe) => (
        <div key={recipe.id}>
          <h3>{recipe.name}</h3>
          <p><strong>Ingredients:</strong> {recipe.ingredients}</p>
          <p><strong>Steps:</strong> {recipe.steps}</p>
          <button onClick={() => handleDelete(recipe.id)}>Delete</button>
        </div>
      ))}
    </div>
  );
}

export default RecipeList;
