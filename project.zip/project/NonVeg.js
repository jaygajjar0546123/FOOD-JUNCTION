import React from 'react';

function NonVeg() {
  return (
    <div>
      <h1>Non-Veg Recipes</h1>
      <p>Explore our selection of non-vegetarian recipes.</p>
    </div>
  );
}

export default NonVeg;
