// SummerSpecial.js
import React, { useState } from 'react';
import './SummerSpecial.css';

const summerRecipes = [
  {
    id: 1,
    title: 'Mango Lassi',
    image: 'https://www.indianveggiedelight.com/wp-content/uploads/2021/05/mango-lassi-1.jpg',
    description: 'A refreshing and creamy yogurt-based drink with ripe mangoes.',
    ingredients: ['Ripe mangoes', 'Yogurt', 'Sugar', 'Ice cubes', 'Cardamom'],
    instructions: [
      'Blend mangoes, yogurt, sugar, and ice cubes until smooth.',
      'Add cardamom powder and serve chilled.'
    ]
  },
  {
    id: 2,
    title: 'Fruit Salad',
    image: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxMTEhUTEhIVFRUVFRUXFRUVFxUVFRcXFxUWFxUVFRUYHSggGBolHRUVIjEhJSkrLi4uFx8zODMtNygtLisBCgoKDg0OGhAQGy0lICUtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLf/AABEIARMAtwMBEQACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAEAgMFBgcBAAj/xABAEAACAQIEBAUCBAQFAgUFAAABAgADEQQFEiEGMUFREyJhcYEykQehscEUQlLwYnKC0eFT8UOSoqPCFRYXIzP/xAAaAQACAwEBAAAAAAAAAAAAAAAAAQIDBAUG/8QAMREAAgIBBAECBQIGAgMAAAAAAAECEQMEEiExQQVREyJhcYGR8BQyobHR4RXBBiMk/9oADAMBAAIRAxEAPwDVqJuZcVhJ2EiNA6i5vAGEiAj0AONABMAPQAGxz2WBOK5M4z3E63KsdhINnZ08Eo2Zhn6AVDplGQ6b5gid/D/M2pvovtzEvxukcrW412bZl+ODKN5M5DDhXiboRG5hmOmcvWa6OFFsI2ADOSOc5+P1dXyWPGiQwGa6+U62m1ayq0VShRK6zNu4hRyRcx7RFSoF5yO8e0jjmtyQu9oTyKC5GoN9ANLipNTU22ZZXPUKKsnDHuZzLuKFdyp6TPD1CDlRZPB7FlwyTqMxCsQekiM7SG0BC4AJqNYXgNAVOoxaNDDIiJwmSQA+KW4gSizLOOMrqqxqUx03ErnHydfSZo9SMwxYcsdQN/WUyi2zpSkn0SHD5KveSXBg1Uk1Rq2QY9iBLEzkT7LXTJKyGV/KQIjMPq3niPU3J5eTTDoBFEuwUczKNJp5Z8iihylRbcty9aSDvPaYcMcMKRTzJi3xFztFLNyXLGJxWNFNbmSWRD+E30ZtxdxuRdU9pHe0zbi0TkgvgPMDUQsxuSJTny7mVz0/wrQ/jqaLUZjzN5gzqc6iieHGnZnmcZjWRj4e253mvFokqbNkMHB9ENiVQbmdo87GLZB51xLSpAnUJXKVF0NPKXgqFP8AEqmawTexIGr+W/vJRkm6NWTQSjDcaJluOFRQQecsaOa1Q5iG3tEhC6S2EGAsxAckgEGA0wHHZerjcQJxlRRuIshopclRBovWZkXlGV0WNrCR2kJ5Gy7Zbkypa0KKWyfo4faRkrBAOZZbqnF13p6zclkJ0D5FgLOSekfp+jWCL9yUnbJjE3M3vka4A6SgHeUTUYq2XRbfCI7NhruOk8lrdfP41QfCOnhxpLkxziPBM9ZlprsDO9ptTeJPI+TWpxgTHBaVqDWb6Y3qMUnwzHnyRmyRzfG66mkc5twJNWT08F2NVcmump7Ca9tI171dIk+Js3qN5QxG5vb9JLczFpNPCraKBmuJN/MxPuSY0bYxjfCIKs14LsWV2an+HXFYFMU6jeZdt+oHIy9StHndRiqVo0fBY9au4PONdGRok7yIjhMaATeMDkAG672UxjTMp48zNi2gG0mRZUcjzapTqi7XBMGBs2Q5mHQe0qZMsNCpERHyAZBqyQFTspaU5Pl4LIHXqgDeQ6ROgDF3b6ZyvU5ZPhP4fZt01J8gtcaVsZ4jbJSpo3qV8kPhspTdiBcmej0ycsXJz82VuQqplyCVZoRhyVKTZVuKUNMq1MC86/pMp5FwaMWdQfJXs2zuuyabgWtPQfBmXx1+BMN4pzEBz95RHlD0s3VFMxOJ1G5Mk+DcpoEepGjPkyJBmDqkbi8mczLNNmt/h9jSVAJlkejDPs0dDtAqFapIDl4AdgAmqlxADO+NeF2q+ZNjJpiKRh+FawbccjBodmg8M4B0AvIjsuuFU2kWIMWIaGcVh9799pnyxssg6Ba1C4sZU+VRanTsCOpGG20xSuL5XBqVNWgDiDNqKDzkX7TFmw48rVKyyO5LkB4ezMYkkJyEni0knx0ZsvHIVnVI01LMdhM2p9PlKSVkIy4soeLxi1buW2GwE9ZodNDBiSSMWWUpPkrWdVxbabJSK4xI3Osb4jlr+gnIjxwexljjjjSIqlTZzYS5cnMyZZIbq4dgbGOipb8jJbC1woAjbCenkuy8cDZgFIHKTh0YssWuzZcvqBkkmU0cZrGNCGa+LVRuZGUkiyGNyfBEYriNF5GUSzxRd/DSQGnFgLAdD1kFqU3Qfw8iyYZ1qLealIonFrhiDgV7SVkB6lhgIWASiyIDeKxQTmecCRIIoZfeVPkkRVdSjWPI8jKGtrLU7QFnOYJTpkk9NpXmraWYk9xltfKq2KLVlYEX2BM5kc2PC6l2a5xb6CuHse2EqCmR5mPKad7rdEr27uGaBmuFFSjdzzH6yqeZwqbD4adxRzIOEsPTogaAb7kkXO86cc0pcpmGWNJ0ymfiJwMoTxMOLG4uo5bnoJNZZeSyEYsxuoTGkdjJJicNiSjbdZNGCTuVFoy/B+ILkSLdHZ0mnVA2YYZVNrSG46EsEas7lOONNxJwkcbWaaLVo3DhDNddP2Aml9WefcadErWxG5iQqKBxfnDawim1zaYNTNrhHb9PxRqxqmyhQSbmYnKuzVLHuY5VVSlxzjUl2hRw0wvhDiEljTY/SbTdp8tqjNr9KktyL5Tr3mw4rQSjQEN43FrTW5MAop1fGvXqqF+kMJXKXsWKJoWBFkA9JEGO1qIYWIjq0RK/nWQrUUq4up/veVSgWxyUVzLuD3pP5KxFP+i37zLk0uPI7aNEdQ0TTcNUdYqFQWHIyP8ADVxEFm9zmOwtSqQi7KCPykFpHN0+ifxlFWTOGq6VCt0HOadjhwZnUnZE8UZmlOkSd9xt8iQnkpF2DA5M+aUoXM3I3ynEYrUNLRNlKityZdcixS+FftK5Hew9cEJmWI1OTK2+aLskqVA+Gw71HVKYuxOwH6n0l0Dl6nIoxbZuPC2WHD0AGO9rmXN+Dzkvmdj1XFbmNEWjPOMCdYbsRMGqXk7egfFAWIxx0TnT54OxhxqxX/1TTT3PSVwu6LpYbYnhKq3is/czp6dUc31KSraazldYsBOimeYkuSVr4paa3JjIoquIrPinsLhBIN2SSJfB4JaYAAiSG2WrBHyiQ8gFyVkRJhYDFTDA7jYxOKGmD1KLD1kdo7PIbdI06AbYbcryVjToi8yyjxhpIlU4KRox53B2j5sq1AplqJSmAYuteDEspJZXiXI0oCx7KCf0kGdzT6iKjyyyZRwZia5BZfDXu3P4EFCyGf1HHHrlml8N8JUcKLgXbqx3Jli46OHn1EsrtkvmVay9hEUIq9TFbySZKiC4kw+tTbtKcsdyN2ky7JFKNZl8rDlObLFTPT4MkZK0epo1QgDlHCHJPNnjCJceHsuIsAJvxQo8xq8+9tmk5Xh9CXM0XRzHyyOxaPiKmnkoMgpbh7aJihhlprYCTSIthOHo3N5IiyYww2lWSPJKLCQYCPQASYAIZ4WOhpnEVhQ0ziK0PkQcRaDaGUPE/hjhbGyEX9TLmkyO9nMF+HOETnSU+4vGuBNsnMJkVCl9NNR7CJsNzDhYchIsLEu3eRGitZ/jv5RAkiEpqYyVhS4XULGMkpUR+I4XDG9pXLGmaceplHphGC4WseUI4kgyapy7LZleUBLbS2kjHKdk1iMMQkw58/zbUW44eWCYWyjaa8caRTN2wmnTJN5aVh9KnaMR3EYtKSl6jBVHNmNhIzaStkopt0iOwmf1WNRzhnWgttDm4qVASB5aVr89x3Fuu0yvJJc1x/UucI9Xz/QsQMvKRJiY0M1JEYO8AB6hkRoEqtIjJOqJrKGC1BECGXWJkhp9ogRE5nj7CwkSSK49IsbmBIIo4aOgsl8HhZJC3DmMxaUhva8G0hrkq9bjykrlbgEGQ+IkOmP0uPEZlCm9z0mfNqFtdFkMfPJcXzAtTuOonEwSnLL8xrlFJCsroXAvPTxXBzJdkxTp2kiIJjs0VG8NFNSsRcUltcD+p2OyL6n4vIuVcLsklfLGsJlRZxWxJFSqN0UX8Kl6U1PNv8Z3PS3KJQ8y7G5eF0TAjaIoTSrG9jIknXgfJkRDFQyJIHdoh0DVWisaQJUaRJUTdVZrM7BKhiEgOvWgMjMS7GRokAnAk7mG0djiYCOhWFU8HHQWFLSsDBgUjPMhxeIc+GjafXYH5vMORZZSpLgvTjFdkB/+KsSxLVcTQpk9Nyf1EvjidckfieyDcJ+GiowLZilx0C/8xPBFqhfElZfcDlgVAv8AFBrddJmZaBKW5Mueodcom8voaRbWrflOjFNGRu3YzXxb1WalhzbSbVa9rqh6pTHJqn5L17GDk5Oo/r/glW3l/oG5fgadFdKDmbsxN3dv6nY7sZYkl0RbbYYsYhVogImtUIqQYWGnEbSDQ7GxiImiSOVGlbRJMDqsJB8E0B1qkBlqqJNRnYLUw8kRoHfCCADLYMQCxP8ACCAWe/hoDQs0FX6zbso3Y/Ei5DOeMA2kAJtfz7nf8pW8iTpj2sdq4bV9TE+xsPyg5+w0jlPLqY/kH6yO5j5HUwaD+VfsIWwO+LSU6boD2uoP2j5I2RuaYk1H/h6Xl2Br1BzpqeSIf+o3/pG/a9OTI/BZGK7D8Ph6aIq0xoVRYAf3v7yyGThURceeQmib+stUrINDmmSsDmvodv0+8BEfmFKxvGITfaIYPUiaJIGqV2HKQaGmA1swbqJBxJpgz48npCh2aHLyoQRAiJKxgIKQsBBX/n094WKhk3P07D+s8z/lErlKiSR2hSUG4G55sdyfmVbmydUKxVNTYdepmbLkhuSLIp0Q2NR03psVPQHdT8QjJrolSfYTkuYGqCrLpdbXHQ+oPUTVBqSKpqmQPGOasW8CkxGm/iWNt7AqL9vSbMGJfzMzZZPpGQ5ghq4li5YaAXqsCQ2ledj0JJVQe7CSyz2Rtd+PuGOG5qy9cDcSvUpVKdQeZape4G1mA2ZupGwHoBOZqI7KibcacrkWzB4tmZrG4uNvjlMunnJcPotyQTVkxha5/wB5tTMzRI0q0mmKhyqB9+knuRGgXEAqNwSPzHt3EknQqBNQHqDyMmREOoPKIYPUpyLRICr4e8TQ0wQ4SRodl+YywgJJjEJ8QdxCgG6tS1lH1Ny/cn0EQCatlFjv+rHuZVOdEoxsFuxO527Snl8st4QNmGJ2KqfciYdXq9qcIdkoKnZEPmrqbEmeZya3OpNGhIaxWahEdna6AXHe/QCb/T9dKc/hyJOClVEDkHF7rXIqp5RezIN7Dowv9jPRQdSJS0jmqgVbM+LmbFVDTon62ZtTqGYG9rJ1AFuRM2w1TS20V5PS1F/NPlkZj0dcA+INjUxNZiR1WnSbQi2/zNUb/SvaUzzbs0V7c/kzRwbJOJI/hniX0VkdSfEdCpttsp3J5AbSjUybaNODC7LrgadSkzEKGuQRvb+xOc80oPhHSjo8coq5f0DcPxEyteuiqvK63JHqe8uw6uTfzqkQ1HpkNv8A6m2/qTa55SIBQ67i4tyt7xav1XDp3Xb+hz4aLJLvgMweahjZhp7b3H/Ep0frWHUT2NbX4+osuklBWuSVDBhO3GVmNoisVS8Nt/oPP0/xD95JOiLQzXwbDdTLRIDqVnHNZHkY02L7iKxjTYwdoWgLpGRKhxdnr0vLTFz/AHvL8cPcrlIzfDcZY3+IVFsxZgoXcbk259I5KgRs+UqdHiObswHsF6Ae/P7TLKXktihZGozOlbss6F6bEL1Iv7D1jk64GlfJCZphmDFgth1tv8icHW4sicp7fvXP5NMNtLkhayBvqnmZzlubZdSITiPDhaVtfMjQp5lhvYd5t9OnJ5k0vuTi0RGTYJq6BbcyWb55Xt7/AJz1+mvJcjr4YrFhU355GM44VS7Em+nYeUk6tjzvfa4muiqbWSuCn55lrUWFPWSu5A1EgHrYdJRkaT4LIaWEo7qBsoVlqg02KMN7j9x1EcPmK54IpFwx/FVVQqnZiASefp/z8zn5tO1N0+DboljnH5u1+7IvGcRFlIvcW68ye9ukphpnfLNs1hUbssWUZ9QwuHp0ySzndzbZdVzov335SvVaBZovaqbfZy3hyTm5vheEXPC40OoINwRcGeVniljlT4aM8okzk+Z3OkncT2fpur+PiV9rs5Gpw7HaLBUUOtvTadhO+DCyOy6pa9Nv5d1/y9viWQfgiE1KYPSTED1MKnW0AG/4FD0EBkzEIpvGWAexdBfbl3E04pIqmmUXgfLTUxbOwtp0oLjk1QkEj2QP95XmfFDijZcQwHlGw/u0wTdujRFC6KWFzJxVIH2Iwr6ndv8AKvwBf95XHmTZZJVFITm1NtBZPqXf3HUSvVKSxuUO1/X3Q8LW6pdMpq4pXDsSAbXXbYnttynjpThmc5ZOHXH7+x1ZaeqSA8/yDx6NKqlQiooDAHdbkfT6Tbp0tLBTjyvP+inY23ErPDmarTXSWGq3La97C9r7GxE7uklS/J6GWBzwwr2Qbjc5GzEg2JJawF7A2uL26za5meOlfVGcZtizVcvyvyHp2mNy3M2TSjGkD4GvpYnsL3/aaMXBgyz4aHcuwhxlSozVRTCi5JF/LyAA+ISflmN5JdR9xQRadilzZj5iF1C1rW2sNrn59JTGW7lHZ+BHFj55f76GkfU29+bNst7nc/T8S2MUyrJl/QuHBGbWIo1CWVvMvS29jp+246GZdToMeZ3JHM1GRrlGj4TCKG1KT94tNoIYG3A5uXUuaplny8nbtOjBOzHJjGbLoqJUHK9j88/1k+mmVsdxmJWmpZjYDeWt0ShBzltXZlHEnHFatU8PCmy8tXMn29Jzs2sr+U9bovRYQhuzdh2T5lj0UayG+4MhDVZPYz6rSaW+ODUa+ORPqYCdU8yot9IZ/jaNQW1A/IguAlBrtEbSwaU8XRCgDV4rm3UhLD9TFN2QSpkjj6m5I59JjkzRELo1vKPaXrorb5OYJAC3qb/t+0rSqVE27Q9VfnHN0hJGP5jndCkzOSaiKToVeTE3IBaeaxenx3uUuj02PHlyLalT8sAzHjipWp+HhMPZmRiPNrZALhiqAWuOfXmNpbPTY1NubqFrj8Lz+/uZXjlCe18lFs1O2zL03uCGA3B6gmdH+b5kdLQaml8OTCHx7sNJbY/7+klvbVHRk0uTuYZFiKa6noVAO+nl72vb5mfHqcM5bYzVmOWaDVJlbxFWdCETk6jKkTXD1CotF6w+k7HsRfSAR2JJ+x7GQzSUSnDe1SYyKguykbryvzBHL/b5la4prpnbxZ/iQqXaEhiLlSQd+WxXcduXXlNEUZJtdfv8h9Coz1PIrO10vYWAI82oEbDpfle8n1wZMjVNG2cMkvTUuLGwuI0cSfDJWjnumstN6RWmx0pUG4v01j+UG2xl2xkK4uyQz1Safsf2MjLogyi/iXmxWmlFT5qlr+1t5m1mXbCj0voGkU5vLLpFZyLLlpr4jc5xFLdyzv6rK5PYiyZZiTVHYdJpwZXM42qwbCrcUZ2zaiWNzyF+XtOzKVlml0ixrlFOw+Y1abBkqMpB6Eyu34Ls0I5FTRsXA2eviBhqlX6kq1KLHvqpAofkn8pYpuS5PLa3AsOWl00XPEHzSEEZpMZxWIC6bHcm1pqjGymTDsTSLKCrFWANioB+CDtb7SmcG+UX434fRnnFXFeMpLUCeDURfK7KCtWmeRFSnqNvcGY8kpVfaO9oNFglJPI3fj2f5M3FU1yE0hRe9kva56m5JPbnt0mLLkaVs9VGGPHBsP4fw64TFK1U2DKyi/IFipB9OUxaucs+BxiuVycXOot8F7zrKaOKpeG/XdXB8wOwBB69OfacXS6vLglcfyjE1zZWuEuC2pVzUrsjimxFMAHc7FahF9rb7d9+gnQ13qsZYlHFab7+n0LZZZtbX0X+rh7r6zz8ZFMZVIpXEGW03DB6SG4IJKi/35zs6TUZINOMmaJY4zXKI/JcRSGHfCeRWWxGsEFrNqDargctQA7rOxmzOS3tfavfyvcxNKD2+xA59liNiGYVFUsLg3uLi1r27j9Jp0U3kx17CjqFjaaBcHw1iKhsinQebmygkXtZW3tfv9p0oY35Fl1SfRKZTQr0nALCqBe6IgTQRy3NhaTe1cMyzuS5NDyDiA1F0JhmuNixOmn22bfV8XlGTU48bpcszPA3y2XLD4IFQSADz25XmmGXckzO41wPZx//ADVe7Af394S5IvoxvinEeNj2HRAB7Tj66duj33peP4OkX1O4nFXIpDl1nOa4ovUe5MsGEOlQEmnGq4Rzc1N8mf8AEtK1YrzHSddpnQUk4ABwAC3Y2MdnPyT54Lp+HFUstemn1KtOsg/xUWN/yf8AKWROH6mtyjL2ZrNOotVVccnAYfPT45fEjGVM5bVoco5euoMek0rIyvYg3GVdCEgb9JFyovxQ3yoz/iXKhVcaPrIbcbA8rhj1FpVLHu6OlDO4oq/C/ClRaxSqwVNXlsLu/wDhUnYf3tMMIYMmVw3JyXjyac3qM1Dgc4vy6mcQyoGVKCqHu25dxquG7AFfm86WHRYk99HIza7LKO2yjUM2q0MVTLVGCFkvuLWDANte1tMya/R45xdRV0/H6f1J6XO+mzYstxKvU1KwKsLgqRYjpY9ec8FlxuKafDX4Ou+YEy1rTnLsqRWeIqagXLAX7m06ejcnwkaYy4B8gpUxRZtIYsb3I78t+1gJ6HFscKkra9zk6qblkYQ+CQrdkQE8hpF/c9uYNucTUUr69q7/ANGdSYPgcHTOqnoIRttiQfcHp8SzTa/KuHJ1+/cdvsVjcvo0ymHTbXYta1ygG4J9SVnRyZXHHx2ycZOXLLZlWDUAKoAA7TFjg5ugnKuywUB25Ts44bVRlkyIz3E+Ygf+Gv8A7j7KPzH2kn9AxxUppPoyPMKBXGVr7Etce05Grg3M9zpc6enidoimh1M1zM6il2SnklLiITj+JEUAKRLXbXyozwwcvcUvMcaWfUO+1+c6Mcm7o05Ybehmq7uRcS5IwZJRRe/wnXRjEv8AzBlPzY//ABk0cfXNOBqVCj4FU0uVKoxakeivzekffmPmKUebOSnRKUG3tHFjaBM+a4UAjreLJFvo06ZqNtkPUW4+Okk0mqfQ3LkisMLVWw1UbaQykbFhqNmB6EWHzPGz070ubhtU+P8AotbvoieLuH8UHqV8O5qeKtnXbVfRoBt7W5T0ml9WjW3M19/8+39vsZMmnvmJmGdUG1MrUGDBtIBsXUjc3UE2J3G21jtOo8mPLDdF2n0yiEZQdPgsn4c5DiRW8az0aQIOliV8Tle6n0vue4nC9RwfFx7Ek37vx+TpafLT5LrxFn7UmWhSTXWfkN7DbmTyt8/E4mn/APHsr+bI0l7Ll/4L/wCKxpmd5/SxwPiVluNQ1WN1F/cDblvvO/h0EMcaiqKsuscuImh5PQIpU1K2YrT1DsdIuPuenK8wfD2tr6mOUrdj2IIO+9hqsPTdQfe/7TFqJJ8/uuhRI7+KCm8xNSkWoOwuTtiqwrs5UAWXSBciw3Ym/aep0/z447hOSjwWKnSaiy0wS199R525W25TbgxxRTOTZPYvFilT1c2Oyr3Yy98FZAYiiQEVjdmcO5+b/tEkSjwV/ijh5ax1g2buNjI5MEZnQ02tliW3wZ7juGKik+ckSn+Fijo/8rLwAjh1jzJliwxRnyeoZJF7zT8OwpJSNYdvRL/lZTXJEf8A2nUB5Se0onq0yycLZUaNam1uTi/zt+8EjHly7zTsZhFqKVYXB5jkfRlPRh3jMpGHxE8rG5OyVOjejf0v+vTsIVtZOLEDC2Us7dLWkl1ZNzvhCcNXonkCfXc79rj2hvj7iakRfE+CFZ1q0dqlNCdV9iP6COfTt0nM12lWe3F81+/yXY+I0/wR+Ez63lqDS29tibntbnPO5MeXGnFo0RTYBgyXxlZrEIdKk2uCwCrftzuJ2fT8jwY1CSfL/uyvPj3cosdDLUXcL6cp2/hx9jC5MHrUNQNRad6gumsfUvOzD22MvwbVGmV5G27Ms4qx+IqYoUEAOy07BrqW/mJYdee3S0ucotfKRpr+Y0athWRwW5sgJ/8AKAVHs2o2/wAU8zrouGd+z5/X/DsvhyhjF0NItfe+/K23QW9T+U4upi4L9/vyXRIqpgi7AAE7i/oL84tLFzkkiwv+V4fSqhQT8T1MI1FUUv6khjSiWdufIAbknsomlRoqbsCRCT41a1wLInRR2Hc9zJr3YiLo4nxHdr3Abb7b/neOHJOSoddbywimR+JwIPSFE1IDbLF7RUPcXiooMkVA7YQdoUFiBghHQmybpNcCVPsZ6tTuCLAg8weRgwIzHYDWhRWIvbynmN+V+o6fvK5QtUiyMqds8FCjTa1hytb8pndrhll2M1aKtsRIcDtgOBy4BmpsBY3IsBuCdgfUcpoxSTVMjkfklqeXIoNhbbp36GWbYlTkwKk+pLj5HYjmJb4srIzOqdSlTVk1eGXJr6Pr02AUgjcDne3YTDq8k8aTj15fsbNJCE21LvwDJw9hriqiC58wqKTqPrqvc/MjDUS92KWOnTQvF4NjaxuwNwx2bfpqAseQ5iV6iKy032umKMaBaWQ1aoOiqtxsyt9Y3JvYHcb87zlv06WWXyyTrv3Jv5Oy0cPZR/D0yHIZiSb2tOzo9KsENpRklb4DGxZ5KAzen0j56/3vNSsg68AzIFOuodT/AKeg7CH3Ar/EuYto0p9bkItumo2LfAuZGbpFuKKcuehOUJZWtyvYewk8S+UhkduwwtLSAhzACv55xTh8N9bi/Ybn7SO9E6Zdkr3jTK2EK0khDqiMB/DneVyXI0OtUsQD15H17SiebbkUGu+n9fb/AATUbVnqiA85dQrBK1IjfTrHbkw9u8TXurGmMBEO4JX0Yf3aUSxQfTompy8nv4dtSsLG19weh/7RRxTjJPwNzTVBZl1FQLSoANfvHF0DQYR0FiDzg+QXBE4vIVF2w9TwWO+j6qJPrTv5f9JEyS0a7xuvp4/0aVqm+Miv+/6/5OUcvaw8Rlv10XI+5tJrTSa5ZB5Y3wRlTI7PdHYC9/MQRv8AVp2vvMz9Lxt25v8AoXrXS21tRL0wEUKWLe5JH5zfCEccdsb/AC2/7mScnN2/7UIqY22y7R2JRAK1YmCAjauxJ68l9z/f5SE34LIhVBQihR05+p6y+CpUVSds8XkrEUbjLjDQfAoHzcmb+n/mZM2bwi7HDnkzXMcNUqE8yxNyT1+Znx5Yp2zRkxPwfROFqzdBmJolqMtRALWADlMQGEMoI+QfkSqeNTq/Dv8AQknR6SEegALXwobe5B9D+x2ikrGnR3wwOW0SSQNtiT7x9COavUw59wO+IIWAhsWo6ROVDoZfHgw3Coj8ZjOgkJMmkCCqTBDOM8YAn8SDcjkOvSEZJ8ok4NdiKS3Os/6R29YKFu2KUuKQ6aktK0gHM6hNN7G1lYk9rCY9VqPhpJdsvxY91tmM4ZC7XNzc335mZ5MsSJ/Jsv1VkBHIMSP9Nv1MzzlUbLIq2bThMGRO1GNHPbJWjSlhEIVYALUQAWIMaO3kWM9eIBLRANNABpjBgMO0iBF5lmJpAHw3cE28guR627Qk6GhaVtQBsRcXsefzF2MHqNYxEhpxeAj1pIAfGoxUqCBfYk9B1sOspzwnOO2Lq/P0LMclGVsFoYFrAXtTHO/1ue3+FfzPpLMOFYoKK8CyZdzsIcy0q7GyYiRE8VYnw8DVbq/kHybfvOLOTyan7G2K24jOsqocpObIxLnwvh1VqldvpQBfkkX/AFH2mbM7SiWR45NeWjPSHLHVSACrQA8IDR2AzxWAA9Ove4IsR9pBr2BMXqEh5JUIeoO8HOK7YbWNMY7FQy8LED1FELAYYREkMnf2iasYyaR6RK0B0UTzJAEaTYm0hFYheW57n9u0mo0Rbs8v0gSQA9RYmMZYRMkiocfVS2CQKdlrWf052v8ANpyIR25p2bJO4IrWWMAOcJISLNlGIvhGIG3j2Y/DW/v2mXURaf4LsfKNrvPSnKPQEcvAZ0QA7AYoGAA1ZdLaunWAhbKCLj8oUgsGrU7i36bGU5MEZxonHI4sDSky/wAzEdjv+YmPT6LLglSyOUfZ9/qXTzwmuY0xbOP+4I/abtpRY2xHf9YbRWNNbvDaPcMu47Ew2isaeuRyAH6x0FgjN/MxjENUwWNzAYWRHQHNEdANtSkGhplA/EbKKpAak2lWI8QXsu3JjMeRRg9zRojclVlRoZTVvpStTPzMb1MV3Fl3wW+maf8Ah5ltSlh3p4lUZGbUCCD9xM2TPjnLiyaxySL3kWbjEUVqja+xHZgbMPuJ6SLtWYdRheHJLG/Af4kdFJ0PCgFhohigYDOwA8RABgqV5br27QEe1A8jAQ06wAYdYAMskAGmWADDxUMEr1eg3PYRANJQZtz9u0dAFU6VowFaIxHtMQ7ONBoZVuP8SFwzLtqfYA8vczJqZRjGmX4U2UPKuF6ta1Rl8Ic/KSNXxM8Mba45+5a5V2XPB5TVC28VgOwO/wB5bDQwXLRXLUSfRP8AA+KC4RBe5DVAT66zeacD+RGr1df/AFz/AH4LEmJl5zaCada8BBCPFQh5TEMXeAHRAZ2ADNXDg+h7jaAqBqmHccmB94CB38QfyA+xgAy1Sp/0/wA4ANMtQ/ygfMAEfwLH6m+BCgHEwQHSOgHPBhQCSkKA4UjASUiARUUAEnpE+BozMocfmJuSaNIfT/Kbcrj++c5m55p8fj7G2lCJdHo2IAAsNhOlGKSoyuVhVGhtJkCm8I40jDqDt5m2/wBRmTDxBI7HqvOqmyz4XGXM0JnMaJvCVL2krK2iSpNGRCkkQFmAxQgMVAD0AEkQAQVgRGysAElI0AkrGA2ywAbKwAQVgB4pABsrACt8e5qKOHKg+Z9vUKPqP7fMw63LtjtXbNGnhbt+CK4Cy/w8MarDzVjf46R6TGkrHml4LDQW5m0zhqpARmmRIVpJfqL/AH3mTGqijsa+fxNROX1ZZct3MuRgkWfBJykylkrSEkQCkEiA7AZ0QGdgB6AHIAcIgISRAQgiACSI7AQwjAQVgAkrABLLABs7bmAGRZ/imx2OWmh8paw/yKdz87mcSUnmzOXjpHQjHZBL8s0R6QUKijZQAPidiEdsUjFJ27H8PTkyIXojQmUWnlxXYDYCwlCibpy3O2TuU4GwEmkUSkmWPDULSRU2HU0gRHgIgFQGKgB6Az0AOQA8YAcMBMSRAQkiMBDCACdMYCSIAJYQArPHWZ+DhyoNnqXUei/zH7bfMx6zNshS7ZfghulfsVT8N8uuamKYc/JT9hzMo0ePm/YtzS4+5dEF2vOmZGH0acBDxWNCZG4nLdxseu4ud9rXHbnv/vINEskroay7CVqV/wD9YcnQA3LyAFbm9uRu2nn5z8RVoyx+JC+L6/T9819QwUK4Jbw7sFIXztp5sSSQ25Oil2tqO225yFZO65+/79l+obVbEebSg5Uim6gE6x4gI5jy36n36mRpXQoUqiFyiDcNYG5uQqFAAXso1GrsLD9ZGMVHoSgl0Ldq4N1VWGgWUgL57VTe+o2uRSHXn7yRMXh3rkrqVQN9VufN7WOrbYU+h+o/AAaYAegByAHjADkBHoAcIgAkiMQi0YxLCAhDCKxmOcb5k2KxIp097sKae19z87n7ThZMnxszn4XR0YQ2QS8sveBwoo0adFeSqPv1M7GCG2C9zFklciSwtOXFYYsaRFizGILAkSQsCADoEiB6BI7ADpgB0QA8YAJgB4wA9AD0AOGAHICEmACTABLRiI3iOoVwtUqbHQd5n1cnHDJr2ZbhSeRJ+5k/CiBsx3F9KMR6Gw3/ADM5GkSqK+qNuV8v7GhXu89AuznslaAkkRHDAieYwA//2Q==',
    description: 'A colorful and healthy mix of fresh seasonal fruits.',
    ingredients: ['Seasonal fruits (apple, banana, watermelon)', 'Honey', 'Lemon juice', 'Mint leaves'],
    instructions: [
      'Chop the fruits into small pieces.',
      'Toss them together with honey and lemon juice.',
      'Garnish with mint leaves and serve chilled.'
    ]
  },
  {
    id: 3,
    title: 'Chilled Buttermilk',
    image: 'https://www.vegrecipesofindia.com/wp-content/uploads/2021/05/chaas-recipe-1.jpg',
    description: 'A cooling and refreshing yogurt-based drink with spices.',
    ingredients: ['Yogurt', 'Cumin powder', 'Salt', 'Water', 'Mint leaves'],
    instructions: [
      'Whisk yogurt and water to a smooth consistency.',
      'Add cumin powder and salt.',
      'Garnish with mint leaves and serve chilled.'
    ]
  }
];

function SummerSpecial() {
  const [openIndex, setOpenIndex] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (e) => {
    setSearchQuery(e.target.value.toLowerCase());
  };

  const filteredRecipes = summerRecipes.filter(recipe =>
    recipe.title.toLowerCase().includes(searchQuery)
  );

  const toggleRecipe = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="summer-container">
      <h1 className="navbar">🌞 Summer Special Recipes</h1>

      <div className="search-container">
        <input
          type="text"
          placeholder="Search for a summer recipe..."
          value={searchQuery}
          onChange={handleSearch}
          className="search-input"
        />
      </div>

      <div className="recipes">
        {filteredRecipes.length > 0 ? (
          filteredRecipes.map((recipe, index) => {
            const isOpen = openIndex === index;
            return (
              <div key={recipe.id} className={`card ${isOpen ? 'open' : ''}`}>
                <div onClick={() => toggleRecipe(index)}>
                  <img src={recipe.image} alt={recipe.title} />
                  <div className="card-body">
                    <h3>{recipe.title}</h3>
                    <p>{recipe.description}</p>
                  </div>
                </div>

                {isOpen && (
                  <div className="recipe-details">
                    <h3>Ingredients:</h3>
                    <ul>
                      {recipe.ingredients.map((ing, i) => <li key={i}>{ing}</li>)}
                    </ul>
                    <h3>Instructions:</h3>
                    <ol>
                      {recipe.instructions.map((step, i) => <li key={i}>{step}</li>)}
                    </ol>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <p>No recipes found. Try searching again!</p>
        )}
      </div>
    </div>
  );
}

export default SummerSpecial;
