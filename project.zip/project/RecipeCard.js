import React from 'react';
import { Link } from 'react-router-dom';
import './Home.css';

const RecipeCard = ({ recipe }) => {
  return (
    <div className="recipe-card">
      <img src={recipe.imageUrl || recipe.image} alt={recipe.name} className="recipe-image" />
      <h3 className="recipe-name">{recipe.name}</h3>
      <p className="recipe-ingredients">{recipe.ingredients}</p>
      <Link to={`/recipe/${recipe.id}`} className="recipe-link">View Recipe</Link>
    </div>
  );
};

export default RecipeCard;
