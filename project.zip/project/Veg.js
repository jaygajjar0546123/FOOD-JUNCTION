import React, { useState } from 'react';
import './Veg.css';

const vegItems = [
  {
    id: 1,
    name: 'Dal Chawal',
    image: 'https://th.bing.com/th/id/OIP.jz8Q3sAC_wn2xmHoWF74WgHaJP?w=148&h=185&c=7&r=0&o=5&dpr=1.3&pid=1.7 ',
    description: 'A classic Indian combination of lentils (dal) and rice (chawal), served with ghee and spices.',
    ingredients: ['Yellow lentils', 'Rice', 'Onion', 'Tomato', 'Ginger', 'Garlic', 'Turmeric', 'Cumin seeds', 'Ghee', 'Spices'],
    recipe: '1. Pressure cook dal with water, turmeric, and salt. 2. Heat ghee in a pan, add cumin seeds, onion, ginger, garlic, and tomatoes. 3. Add cooked dal to the tempering and cook for 10 minutes. 4. Serve with hot steamed rice and ghee.'
  },
  {
    id: 2,
    name: 'Pav Bhaji',
    image: 'https://ts2.mm.bing.net/th?id=OIP.6dndUffso1XhDUxMWlU_KgHaLO&pid=15.1',
    description: 'A popular street food made with a spicy vegetable mash (bhaji) served with buttered pav (bread).',
    ingredients: ['Mixed vegetables (potato, peas, carrots, bell peppers)', 'Onion', 'Tomato', 'Pav bhaji masala', 'Butter', 'Cumin seeds', 'Coriander leaves', 'Bread rolls (pav)'],
    recipe: '1. Boil the vegetables and mash them. 2. Heat butter in a pan, add cumin seeds, onions, and tomatoes. 3. Add mashed vegetables and pav bhaji masala. 4. Cook the mixture and serve with buttered pav and coriander leaves.'
  },
  {
    id: 3,
    name: 'Paneer Bhurji',
    image: 'https://th.bing.com/th/id/OIP.8-IQmHwfzIuD7m48E3pf9gHaHa?w=200&h=200&c=7&r=0&o=5&dpr=1.3&pid=1.7',
    description: 'A scrambled paneer dish made with onions, tomatoes, and Indian spices.',
    ingredients: ['Paneer', 'Onion', 'Tomato', 'Green chilies', 'Ginger', 'Cumin seeds', 'Turmeric', 'Red chili powder', 'Coriander leaves', 'Salt'],
    recipe: '1. Crumble the paneer and set aside. 2. Heat oil in a pan, add cumin seeds, and then sauté onions and tomatoes. 3. Add spices, crumbled paneer, and cook for 5-7 minutes. 4. Garnish with coriander leaves and serve hot.'
  }
];

function Veg() {
  const [openIndex, setOpenIndex] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');

  // Function to handle search query changes
  const handleSearch = (e) => {
    setSearchQuery(e.target.value.toLowerCase());
  };

  // Filter recipes based on the search query
  const filteredVegItems = vegItems.filter((item) =>
    item.name.toLowerCase().includes(searchQuery)
  );

  const toggleRecipe = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="home-container">
      <div className="hero">
        <h1>🍲 Veg Recipes</h1>
        <p>Explore delicious and healthy vegetarian recipes!</p>
      </div>

      <div className="search-container">
        <input
          type="text"
          placeholder="Search for a recipe..."
          value={searchQuery}
          onChange={handleSearch}
          className="search-input"
        />
      </div>

      <h2 className="section-title">✨ Featured Veg Recipes</h2>
      <div className="recipes">
        {filteredVegItems.length > 0 ? (
          filteredVegItems.map((item, index) => {
            const isOpen = openIndex === index;
            return (
              <div className={`card ${isOpen ? 'open' : ''}`} key={item.id}>
                <div onClick={() => toggleRecipe(index)}>
                  <img src={item.image} alt={item.name} />
                  <div className="card-body">
                    <h3>{item.name}</h3>
                    <p>{item.description}</p>
                  </div>
                </div>

                {isOpen && (
                  <div className="recipe-details">
                    <h3>Ingredients:</h3>
                    <ul>
                      {item.ingredients.map((ing, i) => <li key={i}>{ing}</li>)}
                    </ul>
                    <h3>Recipe:</h3>
                    <ol>
                      {item.recipe.split('.').map((step, i) => step.trim() && <li key={i}>{step}</li>)}
                    </ol>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <p>No recipes found. Try searching again!</p>
        )}
      </div>
    </div>
  );
}

export default Veg;
