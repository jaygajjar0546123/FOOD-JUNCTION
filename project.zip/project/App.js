import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import AddRecipe from './AddRecipe';
import RecipeList from './RecipeList';
import Navbar from './Navbar';
import Home from './Home';
import Veg from './Veg';
import Summer from './Summer';
import Signup from "./Signup";
import Login from "./Login";

// Import Firebase


import './App.css';  // Import the animated CSS

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/veg" element={<Veg />} />
        <Route path="/Summer" element={<Summer />} />
        <Route path="/AddRecipe" element={<AddRecipe />} />
        <Route path="/RecipeList" element={<RecipeList />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/login" element={<Login />} />

        

      </Routes>
    </Router>
  );
}

export default App;
