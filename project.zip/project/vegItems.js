const vegItems = [
    {
      id: 1,
      name: 'Paneer Butter Masala',
      image: 'https://www.indianveggiedelight.com/wp-content/uploads/2021/08/paneer-butter-masala-featured.jpg',
      description: 'Creamy and flavorful paneer curry made with tomatoes, butter, and spices.'
    },
    {
      id: 2,
      name: 'Chole Bhature',
      image: 'https://www.whiskaffair.com/wp-content/uploads/2020/04/Chole-Bhature-2-3.jpg',
      description: 'Spicy chickpeas cooked in Punjabi style, served with deep-fried fluffy bhature.'
    },
    {
      id: 3,
      name: 'Mix Veg Curry',
      image: 'https://www.vegrecipesofindia.com/wp-content/uploads/2022/01/mix-veg-curry-1.jpg',
      description: 'Seasonal vegetables cooked in a rich and spicy Indian curry.'
    },
    {
      id: 4,
      name: 'Aloo Gobi',
      image: 'https://www.indianveggiedelight.com/wp-content/uploads/2021/05/aloo-gobi-featured.jpg',
      description: 'Simple dry curry made with potatoes and cauliflower, seasoned with Indian spices.'
    },
    {
      id: 5,
      name: 'Palak Paneer',
      image: 'https://www.vegrecipesofindia.com/wp-content/uploads/2021/06/palak-paneer-3.jpg',
      description: 'Spinach puree cooked with paneer cubes and mild spices.'
    },
    {
      id: 6,
      name: 'Rajma Masala',
      image: 'https://www.cookwithmanali.com/wp-content/uploads/2019/01/Rajma-Masala.jpg',
      description: 'Kidney beans cooked in tomato-onion gravy, popular in North India.'
    },
    {
      id: 7,
      name: 'Veg Pulao',
      image: 'https://www.indianveggiedelight.com/wp-content/uploads/2021/07/vegetable-pulao-featured.jpg',
      description: 'Fragrant rice dish cooked with vegetables and whole spices.'
    },
    {
      id: 8,
      name: 'Kadai Paneer',
      image: 'https://www.vegrecipesofindia.com/wp-content/uploads/2021/05/kadai-paneer-2.jpg',
      description: 'Paneer cooked in a spicy tomato-based gravy with bell peppers.'
    },
    {
      id: 9,
      name: 'Baingan Bharta',
      image: 'https://www.vegrecipesofindia.com/wp-content/uploads/2013/12/baingan-bharta-recipe-1.jpg',
      description: 'Smoky mashed eggplant dish with onions, tomatoes, and spices.'
    },
    {
      id: 10,
      name: 'Matar Paneer',
      image: 'https://www.vegrecipesofindia.com/wp-content/uploads/2019/07/matar-paneer-1.jpg',
      description: 'Peas and paneer cooked in a delicious onion-tomato gravy.'
    }
  ];
  
  