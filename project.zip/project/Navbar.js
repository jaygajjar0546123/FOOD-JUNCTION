import React from 'react';
import { Link } from 'react-router-dom';

function Navbar() {
  return (
    <nav>
      <ul>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/veg">Veg</Link></li>
        <li><Link to="/Summer">Summer</Link></li>
        <li><Link to="/AddRecipe">Add Recipe</Link></li>
        <li><Link to="/RecipeList">Recipe List</Link></li>
        <li><Link to="/signup">Signup</Link></li>
        <li><Link to="/login">login</Link></li>

        

      </ul>
    </nav>
  );
}

export default Navbar;
